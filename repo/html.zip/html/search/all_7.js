var searchData=
[
  ['get_5fexpr_48',['get_expr',['../classUI_1_1UI.html#a952d5f5db3940a8a1e336041b057c89c',1,'UI.UI.get_expr()'],['../namespaceUI__template.html#a0f989a194afd80aba7b87143cd8ee8e8',1,'UI_template.get_expr()']]]
];
