var indexSectionsWithContent =
{
  0: "_abcdefghklmnprstuw",
  1: "tu",
  2: "mptu",
  3: "hmprstu",
  4: "_abcdegkpst",
  5: "adfhklnprsw",
  6: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Pages"
};

