var searchData=
[
  ['power_236',['power',['../TODO_8txt.html#a22b81f859aff7641eee2e02a082f4547',1,'TODO.txt']]]
];
