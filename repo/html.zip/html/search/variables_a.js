var searchData=
[
  ['window_242',['window',['../namespacemain.html#ae1ea5d7d8ba9156ef06beef9bf8901a8',1,'main.window()'],['../namespaceUI__template.html#a248c19a1c29310ed4ae3ffc0ab5c5253',1,'UI_template.window()']]]
];
