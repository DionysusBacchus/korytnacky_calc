var searchData=
[
  ['prostredi_66',['Prostredi',['../md_README.html',1,'']]],
  ['power_67',['power',['../TODO_8txt.html#a22b81f859aff7641eee2e02a082f4547',1,'TODO.txt']]],
  ['prepare_5fdisplay_68',['prepare_display',['../classUI_1_1UI.html#a31f0a3d6bf04caef260eb19d41274e1d',1,'UI::UI']]],
  ['profiling_69',['profiling',['../namespaceprofiling.html',1,'']]],
  ['profiling_2epy_70',['profiling.py',['../profiling_8py.html',1,'']]]
];
