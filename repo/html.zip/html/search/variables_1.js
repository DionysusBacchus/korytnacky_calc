var searchData=
[
  ['data_224',['data',['../namespaceprofiling.html#ab0326054d1b47b84d38c7df0802a0fd9',1,'profiling']]],
  ['data_5faverage_225',['data_average',['../namespaceprofiling.html#acb39f5f7a7d0ccb3914d9b6e8ec616ea',1,'profiling']]],
  ['data_5flen_226',['data_len',['../namespaceprofiling.html#a0063a7b33a4b3bed108140ec6eba0017',1,'profiling']]],
  ['display_227',['display',['../classUI_1_1UI.html#a52f805f9372c4d062b5b01688baaadb6',1,'UI::UI']]],
  ['displaying_5fresult_228',['displaying_result',['../classUI_1_1UI.html#a47bbab2d1435ec2ad2734edc45bd977c',1,'UI.UI.displaying_result()'],['../classUI_1_1UI.html#aa491586a25da14ebd2390ad9645c88d3',1,'UI.UI.displaying_result()']]]
];
