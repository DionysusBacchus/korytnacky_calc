var searchData=
[
  ['skutecnost_2etxt_141',['skutecnost.txt',['../skutecnost_8txt.html',1,'']]]
];
